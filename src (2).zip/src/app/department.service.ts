import { Injectable } from '@angular/core';
import { HttpClient, HttpParams } from '@angular/common/http';
import { Observable } from 'rxjs';
import { Department } from './departments/department';

@Injectable({
  providedIn: 'root'
})
export class DepartmentService {
  private apiUrl = 'http://65.0.155.254:5001/admin/department';

  constructor(private http: HttpClient) { }

  getDepartments(page: number, pageSize: number): Observable<Department[]> {
    const params = new HttpParams().set('page', page.toString()).set('pageSize', pageSize.toString());
    return this.http.get<Department[]>(`${this.apiUrl}`, { params });
  }

  addDepartment(department: Department): Observable<Department> {
    return this.http.post<Department>(`${this.apiUrl}/add`, department);
    }

    updateDepartment(department: Department): Observable<Department> {
      return this.http.put<Department>(`${this.apiUrl}/update/${department.id}}`, department);
      }

}
