import { SigninService } from './../signin.service';
import { Component } from '@angular/core';
import { Router } from '@angular/router';


@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
  password: string = '';
  constructor(private signinService: SigninService, private router: Router) { }

  login(username: string, password: string) {
    this.signinService.login(username, password).subscribe(
      (response)=> {
      console.log("login successful!");
      this.router.navigate(['/dashboard']);
    }
    );
  }

}
