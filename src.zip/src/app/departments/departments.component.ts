import { Component, OnInit } from '@angular/core';
import { DepartmentService } from '../department.service';
import { Department } from '../departments/department';

@Component({
  selector: 'app-departments',
  templateUrl: "./departments.component.html",
  styleUrls: ['./departments.component.css']
})
export class DepartmentsComponent  implements OnInit{
  departments: Department[] = [];
  currentPage = 1;
  pageSize = 10;
  totalItems = 0;

  constructor(private departmentService: DepartmentService) {}

  ngOnInit(): void {
    this.loadDepartments();
  }

  loadDepartments(): void {
    this.departmentService.getDepartments(this.currentPage, this.pageSize)
    .subscribe((data:Department[])=>{
      this.departments = data;
    });
  }

  onPageChange(page: number): void {
    this.currentPage = page;
    this.loadDepartments();
  }
}


